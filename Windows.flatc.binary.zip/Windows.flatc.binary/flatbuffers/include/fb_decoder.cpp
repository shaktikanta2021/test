#include "ClientSchema_generated.h"
#include <iostream>
#include <fstream>
#include "flatbuffers/flatbuffers.h"
#include <cstdio>
using namespace std;
using namespace MySchema::MyClient;

int main(int argc, char *argv[])
{
	///////////////////	
	//Check arguments
	///////////////////
	if (argc != 2)
	{
		cout << "invalid number of arguments. please give valid argument and try again" << endl;
		return 1;
	}
	///////////////////
	//Read BIN file
	///////////////////
	std::ifstream rf(argv[1], ios::binary | ios:: in);
	if (!rf)
	{
		cout << "Cannot open file!" << endl;
		return 1;
	}
	rf.seekg(0, std::ios::end);
	int length = rf.tellg();
	rf.seekg(0, std::ios::beg);
	char *data = new char[length];
	rf.read(data, length);
	rf.close();
	if (!rf.good())
	{
		cout << "Error occurred at reading time!" << endl;
		delete[] data;
		return 1;
	}

	flatbuffers::Verifier verifier(reinterpret_cast< unsigned char*> (data), length);
	bool ok = VerifyClientBuffer(verifier);

	if (!ok)
	{
		cout << "file cannot be decoded!!" << endl;
		delete[] data;
		return 1;
	}
	///////////////////
	//Deserialize
	///////////////////
	auto myClient = GetClient(data);
	auto clientType = myClient->client_type();

	if (clientType == ClientType_Person)
	{
		auto myPerson = static_cast<const Person*> (myClient->client());
		auto myName = myPerson->the_name()->c_str();
		auto myAge = static_cast<const IndividualAge*> (myPerson->the_age());
		auto myWt = myPerson->the_wt();
		auto myGn = ((myPerson->the_gn() == Gender_Male) ? "M" : "F");

		//show on cmd
		cout << "values decoded as below" << endl;
		cout << "{" << myName << ", " << (short) myAge->age() << ", " << myWt << ", " << myGn << "}" << endl;
	}
	else if (clientType == ClientType_Group)
	{
		auto myGroup = static_cast<const Group*> (myClient->client());
		auto myGrpName = myGroup->the_group_name()->c_str();
		auto myAvAge = static_cast<const AverageAge*> (myGroup->the_av_age());
		auto myAvWt = myGroup->the_av_wt();
		auto myNames = myGroup->the_names();

		//show on cmd
		cout << "values decoded as below" << endl;
		cout << "{" << myGrpName << ", " << myAvAge->av_age() << ", " << myAvWt << ", {";

		//CreateVectorOfStrings
		for (int count = 0; count < myNames->size(); ++count)
			cout << myNames->Get(count)->str() << " ,";
		cout << "}" << endl;
	}

	delete[] data;

	return 0;
}
