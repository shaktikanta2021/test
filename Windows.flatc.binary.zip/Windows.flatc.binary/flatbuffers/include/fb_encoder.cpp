#include "ClientSchema_generated.h"
#include <iostream>
#include <fstream>
#include "flatbuffers/flatbuffers.h"
#include <string>
using namespace std;
using namespace MySchema::MyClient;

int main(int argc, char *argv[])
{
	///////////////////////
	//validate arguments
	///////////////////////
	if (argc != 2)
	{
		cout << "invalid number of arguments. please give valid argument and try again" << endl;
		return 1;
	}

	///////////////////////
	//Take input form command prompt and valdate
	///////////////////////
	cout << "Please give input.." << endl;
	cout << "..................." << endl;
	cout << "1. employee details" << endl;
	cout << "2. Group details" << endl;
	int input;
	cin >> input;

	while ((1 != input) && (2 != input))
		cin >> input;

	uint8_t *buf = NULL;
	unsigned int size = 0;
	if ((1 == input) || (2 == input))
	{

		if (1 == input)	//Person
		{
			string ipFullName;
			short ipAge;	// can hold upto numeric value 0 to 120(valldation later) and safe for "byte" of schema
			float ipWt;	// can hold upto 0 to 1000 (valldation later) and safe for "short" of schema
			char ipGn;	//  can hold "M" or "F" and coverted to enum "byte" of schema 

			cout << "Give input for name:";
			cin.ignore();
			getline(cin, ipFullName);
			cout << "Give input for age Years(must be positive whole number):";
			cin >> ipAge;
			cout << "Give input for weight KG(must be positive whole/floating number):";
			cin >> ipWt;
			cout << "Give input for gender(M/F):";
			cin >> ipGn;

			///////////////////////
			//validation to make sure (1) entered data is logically correct (2)should not be problem for schema type
			///////////////////////
			if ((!ipFullName.size()) || (ipAge < 0) || (ipAge > 120) || (ipWt < 0.0f) || (ipWt > 1000.0f) || ((70 != ipGn) && (77 != ipGn)))
			{
				cout << "Input data has some issue" << endl;
				//delete the input file??
				return 1;
			}
			///////////////////////
			//Serialize
			///////////////////////
			flatbuffers::FlatBufferBuilder builder(1024);
			auto nameToStore = builder.CreateString(ipFullName.c_str());
			auto myAge = IndividualAge((char) ipAge);
			auto myAgeSt = builder.CreateStruct(myAge);
			auto myPerson = CreatePerson(builder, nameToStore, AgeValue_IndividualAge, myAgeSt.Union(), ipWt, (70 == ipGn) ? Gender_Female : Gender_Male);
			auto orc = CreateClient(builder, ClientType_Person, myPerson.Union());

			builder.Finish(orc);
			buf = builder.GetBufferPointer();
			size = builder.GetSize();
		}
		else	//Group
		{
			string ipGrpName;
			float ipAvAge;	// can hold upto value 0 to 120(valldation later) and safe for "float" of schema
			float ipAvWt;	// can hold upto 0 to 1000 (valldation later) and safe for "float" of schema
			std::vector<std::string > iNames;

			cout << "Give input for name:";
			cin.ignore();
			getline(cin, ipGrpName);
			cout << "Give input for age Years(must be positive whole/floating number):";
			cin >> ipAvAge;
			cout << "Give input for weight KG(must be positive whole/floating number):";
			cin >> ipAvWt;

			string iName;
			cout << "Give names: put enter after each name. type \"end\" to end input " << endl;

			cin.ignore();
			getline(cin, iName);
			while (iName != "end")
			{
				iNames.push_back(iName);
				getline(cin, iName);
			}
			///////////////////////
			//validation to make sure (1) entered data is logically correct (2)should not be problem for schema type
			///////////////////////
			if ((!ipGrpName.size()) || (!iNames.size()) || (ipAvAge < 0.0f) || (ipAvAge > 120.0f) || (ipAvWt < 0.0f) || (ipAvWt > 1000.0f))
			{
				cout << "Input data has some issue" << endl;
				//delete the input file??
				return 1;
			}
			///////////////////////
			//Serialize
			///////////////////////
			flatbuffers::FlatBufferBuilder builder(1024);
			auto nameToStore = builder.CreateString(ipGrpName.c_str());
			auto myAvAge = AverageAge(ipAvAge);
			auto myAvAgeSt = builder.CreateStruct(myAvAge);
			auto myNames = builder.CreateVectorOfStrings(iNames);
			auto myGroup = CreateGroup(builder, nameToStore, AgeValue_AverageAge, myAvAgeSt.Union(), ipAvWt, myNames);
			auto orc = CreateClient(builder, ClientType_Group, myGroup.Union());

			builder.Finish(orc);
			buf = builder.GetBufferPointer();
			size = builder.GetSize();
		}

		///////////////////////
		//Write to BIN file
		///////////////////////
		if ((NULL != buf) && size)
		{
			ofstream wf(argv[1], ios::out | ios::binary);
			if (!wf)
			{
				cout << "Cannot open file!" << endl;
				return 1;
			}
			wf.write((char*) buf, size);	// overwrite
			wf.close();
			if (!wf.good())
			{
				cout << "Error occurred at writing time!" << endl;
				return 1;
			}

			cout << "Encoded successfully!!" << endl;
		}
	}

	return 0;
}
